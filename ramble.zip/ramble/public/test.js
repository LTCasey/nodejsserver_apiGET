const axios = require('axios');

axios.get('http://localhost:3000/getData') // Update the URL if needed
  .then((response) => {
    const { followers, subscribers } = response.data;

    const numFollowers = followers.num_followers;
    const latestFollowerUsername = followers.latest_follower.username;
    const numSubscribers = subscribers.num_subscribers;
    const latestSubscriberUsername = subscribers.latest_subscriber.user;

    console.log('Followers:');
    console.log('Number of Followers:', numFollowers);
    console.log('Latest Follower Username:', latestFollowerUsername);

    console.log('Subscribers:');
    console.log('Number of Subscribers:', numSubscribers);
    console.log('Latest Subscriber Username:', latestSubscriberUsername);
  })
  .catch((error) => {
    console.error('Error:', error.message);
  });
