// index.js

const numFollowersSpan = document.getElementById('numFollowers');
const latestFollowerUsernameSpan = document.getElementById('latestFollowerUsername');
const numSubscribersSpan = document.getElementById('numSubscribers');
const latestSubscriberUsernameSpan = document.getElementById('latestSubscriberUsername');

function fetchData() {
  axios.get('/getData')
    .then((response) => {
      const { followers, subscribers } = response.data;

      const numFollowers = followers.num_followers;
      const latestFollowerUsername = followers.latest_follower.username;
      const numSubscribers = subscribers.num_subscribers;
      const latestSubscriberUsername = subscribers.latest_subscriber.user;

      // Set the content of the spans with the fetched data
      numFollowersSpan.textContent = numFollowers;
      latestFollowerUsernameSpan.textContent = latestFollowerUsername;
      numSubscribersSpan.textContent = numSubscribers;
      latestSubscriberUsernameSpan.textContent = latestSubscriberUsername;
    })
    .catch((error) => {
      console.log(error);
      // Optionally handle errors here
    });
}

// Fetch data initially and set an interval to refresh every 60 seconds (adjust as needed)
fetchData();
setInterval(fetchData, 60000);
