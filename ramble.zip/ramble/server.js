// server.js
const express = require('express');
const axios = require('axios');
const path = require('path');

const app = express();
const port = process.env.PORT || 3000;

app.use(express.static('public'));

app.get('/getData', async (req, res) => {
  try {
    const response = await axios.get('https://rumble.com/-livestream-api/get-data?key=0me1clTKb6jODPcPvZTqj6SA_5cervHSucsmVpUEJqOIj3g3PpsGNQJWfGVp7wJ8wN2CwTutNfoc33tzqXtLVA');
    res.json(response.data);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while fetching the data' });
  }
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
